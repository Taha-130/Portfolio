import sqlite3
import random
from flask import Flask, session, render_template, request, g

app = Flask(__name__)
app.secret_key = "select_a_COMPLEX_secret_key_please"
app.config["SESSION_COOKIE_NAME"] = "myCOOKIE_Monster528"

# Page d'accueil
@app.route("/", methods=["POST", "GET"])
def index():
    # Récupérer les données de la base de données et les stocker dans la session
    session["all_items"], session["shopping_items"] = get_db()
    return render_template("index.html", all_items=session["all_items"], shopping_items=session["shopping_items"])

# Ajouter des éléments à la liste de courses
@app.route("/add_items", methods=["POST"])
def add_items():
    # Récupérer l'élément sélectionné depuis le formulaire
    selected_item = request.form["select_items"]
    # Ajouter l'élément à la liste de courses dans la session
    session["shopping_items"].append(selected_item)
    return render_template("index.html", all_items=session["all_items"], shopping_items=session["shopping_items"])

# Supprimer des éléments de la liste de courses
@app.route("/remove_items", methods=["POST"])
def remove_items():
    # Récupérer les cases à cocher sélectionnées depuis le formulaire
    checked_boxes = request.form.getlist("check")

    # Parcourir les éléments sélectionnés
    for item in checked_boxes:
        if item in session["shopping_items"]:
            # Supprimer l'élément de la liste de courses dans la session
            session["shopping_items"].remove(item)
            session.modified = True
    return render_template("index.html", all_items=session["all_items"], shopping_items=session["shopping_items"])

# Récupérer les données de la base de données
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        # Connexion à la base de données
        db = g._database = sqlite3.connect('actions_list.db')
        cursor = db.cursor()
        # Récupérer les intitulés des actions depuis la table "Action"
        cursor.execute("SELECT Intitule FROM Action")
        all_data = cursor.fetchall()
        # Convertir les données en une liste de chaînes de caractères
        all_data = [str(val[0]) for val in all_data]
        
        # Générer une liste de courses aléatoire
        shopping_list = all_data.copy()
        random.shuffle(shopping_list)
        shopping_list = shopping_list[:5]
        
    return all_data, shopping_list

import subprocess

# Modifier la base de données
@app.route("/modify_database", methods=["GET"])
def modify_database():
    db_file = "actions_list.db"  # Chemin vers le fichier de base de données

    try:
        # Ouvrir DB Browser for SQLite avec le fichier de base de données
        subprocess.Popen(["/Applications/DB Browser for SQLite.app/Contents/MacOS/DB Browser for SQLite", "actions_list.db"])
    except OSError:
        # Gérer le cas où DB Browser for SQLite n'est pas trouvé sur le système
        return "Erreur : DB Browser for SQLite n'est pas installé ou introuvable."

    return "Ouverture de DB Browser for SQLite en cours..."

# Fermer la connexion à la base de données à la fin de chaque requête
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None) 
    if db is not None:
        db.close()

if __name__ == '__main__':
    app.run()
