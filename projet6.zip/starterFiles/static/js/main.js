function check_me(input_id) {
    // Sélectionne l'élément input correspondant à l'id fourni
    var checked_input = document.querySelector("input[id=" + input_id + "]");
    // Sélectionne l'élément label correspondant à l'id fourni
    var checked_label = document.querySelector("label[name=" + input_id + "]");
    
    // Vérifie si la case à cocher est cochée
    if (checked_input.checked) {
        // Applique le style de texte barré au label
        checked_label.style.textDecoration = "line-through";
    } else {
        // Réinitialise le style de texte du label
        checked_label.style.textDecoration = "";
    }
    
    // Modifie le bouton de suppression
    var btn = document.getElementById("remove_btn");
    btn.value = "SUPRIMER ACTION(S)";
    btn.style.color = "FFFFFF";
    btn.style.backgroundColor = "FE7575";
    btn.style.cursor = "pointer";
}
