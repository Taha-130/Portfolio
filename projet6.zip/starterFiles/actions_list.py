import sqlite3
# Notre liste des actions dans la table composée de l'intitulé, le pourcentage et l'objectif

actions = [
    ("ranger", "50%", "Organiser la maison"),
    ("nettoyer", "75%", "Nettoyer les surfaces"),
    ("planifier", "30%", "Planifier la semaine"),
    ("acheter", "10%", "Faire les courses"),
    ("travailler", "90%", "Terminer le rapport"),
    ("étudier", "60%", "Réviser pour l'examen"),
    ("jouer", "20%", "Jouer de la guitare"),
    ("se détendre", "40%", "Faire du yoga"),
    ("courir", "80%", "Courir 5 km"),
    ("lire", "70%", "Lire un livre"),
    ("cuisiner", "65%", "Préparer un repas"),
    ("peindre", "15%", "Faire une peinture"),
    ("jardiner", "55%", "Entretenir le jardin"),
    ("programmer", "85%", "Développer une application"),
    ("méditer", "25%", "Pratiquer la méditation"),
    ("voyager", "90%", "Planifier un voyage"),
    ("bricoler", "45%", "Réparer un meuble"),
    ("écouter de la musique", "60%", "Découvrir de nouveaux artistes"),
    ("apprendre une langue", "70%", "Pratiquer la conversation"),
    ("danser", "35%", "Prendre des cours de danse"),
    ("se relaxer", "50%", "Prendre un bain relaxant")
]

connection = sqlite3.connect("actions_list.db")
cursor = connection.cursor()

# Supprimer la table si elle existe déjà
cursor.execute("DROP TABLE IF EXISTS Action")

# Créer la table Action avec les colonnes spécifiées
cursor.execute("""
    CREATE TABLE Action (
        ID INTEGER PRIMARY KEY AUTOINCREMENT,
        Intitule TEXT,
        Taux_avancement TEXT,
        Objectif TEXT
    )
""")


# Insérer les actions dans la table
for action in actions:
    cursor.execute("INSERT INTO Action (Intitule, Taux_avancement, Objectif) VALUES (?, ?, ?)", action)
    print("added", action)

# ...


connection.commit()
connection.close()
