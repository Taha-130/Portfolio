Action List Application
    Cette application Flask permet de gérer une liste d'actions à réaliser, avec la possibilité d'ajouter, supprimer et modifier les éléments de la liste. Les données sont stockées dans une base de données SQLite.

Fonctionnalités : 

Affichage de la liste des actions à réaliser.
    Ajout d'actions à la liste.
    Suppression d'actions de la liste.
    Modification des actions existantes dans la base de données.
    Ouvrir la base de données dans DB Browser for SQLite pour une édition graphique.

Prérequis : 
    Python 3.x
    Flask
    SQLite