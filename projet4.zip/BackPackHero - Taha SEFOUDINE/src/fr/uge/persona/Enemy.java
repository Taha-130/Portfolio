package fr.uge.persona;

import java.util.Objects;
import java.util.Random;

public class Enemy {
	private int healthPoints;
	private int attackPoints;
	private int defensePoints;
	Random random = new Random();

	public Enemy() {
		this.healthPoints = 10 + random.nextInt(10); // Points de vie aléatoires entre 10 et 20
		this.attackPoints = random.nextInt(6); // Points d'attaque aléatoires
		this.defensePoints = 0;
	}

	/**
	 * Retourne les points de vie de l'ennemi.
	 */
	public int getHealthPoints() {
		return healthPoints;
	}

	/**
	 * Retourne les points d'attaque de l'ennemi.
	 */
	public int getAttackPoints() {
		return attackPoints;
	}

	/**
	 * Retourne les points de défense de l'ennemi.
	 */
	public int getDefensePoints() {
		return defensePoints;
	}

	/**
	 * Vérifie si l'ennemi est vivant.
	 */
	public boolean isAlive() {
		return healthPoints > 0;
	}

	/**
	 * Attaque le héros en lui infligeant des dégâts.
	 * 
	 * @param hero Le héros attaqué.
	 */
	public void attack(Hero hero) {
		Objects.requireNonNull(hero, "hero ne peut être nul");

		int damage = this.attackPoints;
		hero.takeDamage(damage);
		System.out.println("L'ennemi attaque et inflige " + damage + " dégâts !");
	}

	/**
	 * Augmente la défense de l'ennemi d'un point.
	 */
	public void defend() {
		defensePoints++;
		System.out.println("L'ennemi augmente sa défense de 1 point !");
	}

	/**
	 * Inflige des dégâts à l'ennemi.
	 * 
	 * @param damage Les dégâts infligés.
	 */
	public void takeDamage(int damage) {
		healthPoints -= damage;
		if (healthPoints < 0) {
			healthPoints = 0;
		}
	}

	/**
	 * Simule un combat entre l'ennemi et le héros jusqu'à ce que l'un des deux soit
	 * vaincu.
	 * 
	 * @param hero Le héros combattant.
	 */
	public void fight(Hero hero) {
		Objects.requireNonNull(hero, "hero ne peut être nul");
		while (isAlive() && hero.isAlive()) {
			hero.attack(this);
			if (isAlive()) {
				attack(hero);
			}
		}

		if (isAlive()) {
			System.out.println("L'ennemi a vaincu le héros !\n");
		} else {
			System.out.println("Le héros a vaincu l'ennemi !\n");
		}
	}
}
