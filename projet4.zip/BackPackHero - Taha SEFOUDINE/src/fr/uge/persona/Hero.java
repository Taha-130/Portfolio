package fr.uge.persona;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import fr.uge.items.Armor;
import fr.uge.items.Bow;
import fr.uge.items.DisplayButton;
import fr.uge.items.Gold;
import fr.uge.items.Item;
import fr.uge.items.MagicObject;
import fr.uge.items.ManaStone;
import fr.uge.items.Shield;
import fr.uge.items.Sword;
import fr.uge.mvc.Controler;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.Event.Action;

public class Hero {
	private Random random = new Random();

	private int initialHealthPoints; // Points de vie initiaux du héros
	private static int healthPoints; // Points de vie actuels du héros (partagés par toutes les instances)
	private int defensePoints; // Points de défense du héros
	private int experiencePoints; // Points d'expérience du héros
	private List<Item> backpack; // Sac à dos contenant les objets du héros
	private int heroHealthAfterCombat; // Nouvelle variable pour stocker les points de vie précédents
	public static int previousHealthPoints = 40; // Points de vie précédents (partagés par toutes les instances)

	public Hero() {
		this.initialHealthPoints = 40;
		this.healthPoints = initialHealthPoints;
		this.defensePoints = 0;
		this.experiencePoints = 40;
		this.backpack = new ArrayList<>(10);

	}

	public static int getHealthPoints() {
		return healthPoints;
	}

	public void setHealthPoints(int healthPoints) {
		this.healthPoints = healthPoints;
	}

	public int getDefensePoints() {
		return defensePoints;
	}

	public void setDefensePoints(int defensePoints) {
		this.defensePoints = defensePoints;
	}

	public int getExperiencePoints() {
		return experiencePoints;
	}

	public void setExperiencePoints(int experiencePoints) {
		this.experiencePoints = experiencePoints;
	}

	public void takeDamage(int damage) {
		healthPoints -= damage;
		if (healthPoints < 0) {
			healthPoints = 0;
		}
	}

	public void decreaseExperiencePoints(int amount) {
		experiencePoints -= amount;
	}

	public void increaseHealthPoints(int amount) {
		healthPoints += amount;
	}

	public void attack(Enemy enemy) {
		Objects.requireNonNull(enemy, "enemy ne peut être nul");

		int damage = 1 + (int) (Math.random() * 5); // Calcul des dégâts infligés par le héros
		enemy.takeDamage(damage); // Réduction des points de vie de l'ennemi
		System.out.println("Hero attaque et inflige " + damage + " dégâts!"); // Affichage du message d'attaque
	}

	public void fight(Enemy enemy, DisplayButton attackButton, DisplayButton defenseButton,
			ApplicationContext context) {
		Objects.requireNonNull(enemy, "enemy ne peut être nul");
		Objects.requireNonNull(attackButton, "attackButton ne peut être nul");
		Objects.requireNonNull(defenseButton, "defenseButton ne peut être nul");
		Objects.requireNonNull(context, "context ne peut être nul");

		while (isAlive() && enemy.isAlive()) { // Boucle de combat tant que le héros et l'ennemi sont vivants
			var event = context.pollOrWaitEvent(10); // Récupération de l'événement de la fenêtre
			if (event != null && event.getAction() == Action.POINTER_DOWN) { // Vérification si un bouton est cliqué
				handleButtonClick(event, attackButton, defenseButton, enemy); // Traitement du clic sur les boutons
			}
			updateHealthPointsDisplay(context, enemy); // Mise à jour de l'affichage des points de vie
			endCombat(); // Fin du combat (réinitialisation des points de vie du héros)

		}

		handleFightResult(enemy); // Traitement du résultat du combat (victoire ou défaite)
	}

	public static void endCombat() {
		previousHealthPoints = getHealthPoints(); // Sauvegarde des points de vie actuels avant la réinitialisation
		resetHealthPoints(); // Réinitialisation des points de vie
	}

	public static void resetHealthPoints() {
		healthPoints = previousHealthPoints; // Rétablissement des points de vie précédents
	}

	private void handleButtonClick(Event event, DisplayButton attackButton, DisplayButton defenseButton, Enemy enemy) {
		Objects.requireNonNull(attackButton, "attackButton ne peut être nul");
		Objects.requireNonNull(defenseButton, "defenseButton ne peut être nul");
		Objects.requireNonNull(enemy, "enemy ne peut être nul");
		var location = event.getLocation();
		int mouseX = (int) location.getX();
		int mouseY = (int) location.getY();
		if (attackButton.isClicked(mouseX, mouseY)) {
			attack(enemy); // Attaque de l'ennemi
			if (enemy.isAlive()) {
				enemy.attack(this); // L'ennemi contre-attaque si encore en vie
				System.out.println("L'ennemi attaquera au prochain tour !");
			}
		} else if (defenseButton.isClicked(mouseX, mouseY)) {
			defend(); // Le héros se défend
			if (enemy.isAlive()) {
				boolean defend = random.nextBoolean();
				if (defend) {
					enemy.defend(); // L'ennemi se défend si le héros se défend
					System.out.println("L'ennemi se défendra au prochain tour !");
				} else {
					enemy.attack(this); // L'ennemi attaque si le héros ne se défend pas
					System.out.println("L'ennemi attaquera au prochain tour !");
				}
			}
		}
	}

	private void updateHealthPointsDisplay(ApplicationContext context, Enemy enemy) {
		Objects.requireNonNull(context, "context ne peut être nul");
		Objects.requireNonNull(enemy, "enemy ne peut être nul");
		context.renderFrame(graphics -> {
			graphics.setColor(Color.RED);
			graphics.clearRect(10, 10, 200, 20);
			graphics.clearRect(10, 30, 200, 20);
			graphics.drawString("Hero HP: " + getHealthPoints(), 10, 20);
			graphics.drawString("Enemy HP: " + enemy.getHealthPoints(), 10, 40);
		});
	}

	public void handleFightResult(Enemy enemy) {
		Objects.requireNonNull(enemy, "enemy ne peut être nul");

		if (isAlive()) {
			System.out.println("Le héros a vaincu l'ennemi !");
			this.gainExperience(10); // Le héros gagne de l'expérience
			String[] items = { "sword", "bow", "gold", "manastone", "shield", "armor", "magiobject" };
			int index = random.nextInt(items.length);
			String itemName = items[index];

			switch (itemName) {
			case "sword":
				Item sword = new Sword("Sword", 20); // Création d'une épée
				takeItem(sword); // Le héros prend l'épée
				break;
			case "bow":
				Item bow = new Bow("Bow", 15, 10); // Création d'un arc
				takeItem(bow); // Le héros prend l'arc
				break;
			case "gold":
				Item gold = new Gold("Gold", 100); // Création d'or
				takeItem(gold); // Le héros prend l'or
				break;
			case "manastone":
				Item manastone = new ManaStone("ManaStone", 5); // Création d'une pierre de mana
				takeItem(manastone); // Le héros prend la pierre de mana
				break;
			case "shield":
				Item shield = new Shield("Shield", 10); // Création d'un bouclier
				takeItem(shield); // Le héros prend le bouclier
				break;
			case "armor":
				Item armor = new Armor("Armor", 30); // Création d'une armure
				takeItem(armor); // Le héros prend l'armure
				break;
			case "magiobject":
				Item magiObject = new MagicObject("Magic_object", 25); // Création d'un objet magique
				takeItem(magiObject); // Le héros prend l'objet magique
				break;
			}
		} else {
			System.out.println("Le héros a été vaincu par l'ennemi !");
		}
	}

	public void defend() {
		System.out.println("Hero se défend et augmente sa défense !");
		this.healthPoints += random.nextInt(3); // Le héros augmente ses points de vie
		if (healthPoints > 40) {
			healthPoints = 40; // Limite les points de vie à 40
		}
	}

	public boolean addItemToBackpack(Item item) {
		Objects.requireNonNull(item, "item ne peut être nul");

		if (backpack.size() < 10) {
			return backpack.add(item); // Ajoute un objet au sac à dos s'il y a de la place
		}
		return false; // Renvoie faux si le sac à dos est plein
	}

	public boolean removeItemFromBackpack(Item item) {
		Objects.requireNonNull(item, "item ne peut être nul");
		return backpack.remove(item); // Supprime un objet du sac à dos
	}

	public List<Item> getBackpack() {
		return Collections.unmodifiableList(backpack); // Renvoie une vue en lecture seule de la liste d'objets du sac à
														// dos
	}

	public boolean isAlive() {
		return healthPoints > 0; // Vérifie si le héros est en vie en fonction de ses points de vie
	}

	public void takeItem(Item item) {
		if (addItemToBackpack(item)) {
			System.out.println("Hero a pris l'objet : " + item.getName());
		} else {
			System.out.println("Le sac à dos est plein, l'objet ne peut pas être pris !");
		}
	}

	public void gainExperience(int experience) {
		experiencePoints += experience; // Augmente les points d'expérience du héros
		System.out.println("Hero a gagné " + experience + " points d'expérience !");
	}



}
