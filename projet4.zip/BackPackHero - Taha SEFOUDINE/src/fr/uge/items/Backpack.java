package fr.uge.items;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class Backpack {
	private final List<Item> items;

	// Constructor for creating a Backpack object
	public Backpack() {
		items = new ArrayList<>();
	}

	// Checks if an item can be added to the backpack
	public boolean canAddItem(Item item) {
		Objects.requireNonNull(item, "item ne peut être nul");

		// As this implementation does not have any restrictions on adding items, it
		// always returns true
		return true;
	}

	// Adds an item to the backpack
	public boolean addItem(Item item) {
		Objects.requireNonNull(item, "item ne peut être nul");

		// Adds the item to the list of items in the backpack
		return items.add(item);
	}

	// Removes an item from the backpack
	public boolean removeItem(Item item) {
		Objects.requireNonNull(item, "item ne peut être nul");

		// Removes the item from the list of items in the backpack
		return items.remove(item);
	}

	// Returns the list of items in the backpack
	public List<Item> getItems() {
		return items;
	}

	// Returns a string representation of the backpack and its contents
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Backpack contents:\n");
		for (Item item : items) {
			sb.append("- ").append(item.getName()).append("\n");
		}
		return sb.toString();
	}
}
