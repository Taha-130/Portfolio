package fr.uge.items;

public interface Item {
	String getName();

	int itemWidth();

	int itemHeight();

}
