package fr.uge.items;

import java.util.Objects;

public record Armor(String name, int defense) implements Item {

	// Constructor for creating an Armor object
	public Armor(String name, int defense) {
		Objects.requireNonNull(name, "name ne peut être nul");

		this.name = name;
		this.defense = defense;
	}

	// Returns the name of the armor
	@Override
	public String getName() {
		return name;
	}

	// Returns the defense value of the armor
	public int getDefense() {
		return defense;
	}

	// Returns the name of the armor as a string representation
	@Override
	public String toString() {
		return getName();
	}

	// Returns the width of the armor item (implemented from the Item interface)
	@Override
	public int itemWidth() {
		// Returns a fixed width of 2
		return 2;
	}

	// Returns the height of the armor item (implemented from the Item interface)
	@Override
	public int itemHeight() {
		// Returns a fixed height of 2
		return 2;
	}
}
