package fr.uge.items;

import java.util.Objects;

public record Gold(String name, int value) implements Item {

	// Constructor for creating a Gold object
	public Gold(String name, int value) {
		Objects.requireNonNull(name, "name ne peut être nul");
		Objects.requireNonNull(value, "value ne peut être nul");

		this.name = name;
		this.value = value;
	}

	// Returns the name of the gold
	@Override
	public String getName() {
		return name;
	}

	// Returns the value of the gold
	public int getValue() {
		return value;
	}

	// Returns a string representation of the gold
	@Override
	public String toString() {
		return getName();
	}

	// Returns the width of the gold item (assuming the width is 1)
	@Override
	public int itemWidth() {
		// TODO Auto-generated method stub
		return 1;
	}

	// Returns the height of the gold item (assuming the height is 1)
	@Override
	public int itemHeight() {
		// TODO Auto-generated method stub
		return 1;
	}

}
