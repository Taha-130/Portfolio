package fr.uge.items;

import java.util.Objects;

public record Shield(String name, int defense) implements Item {

	// Constructor for creating a Shield
	public Shield(String name, int defense) {
		Objects.requireNonNull(name, "name ne peut être nul");
		this.name = name;
		this.defense = defense;
	}

	// Returns the name of the Shield
	@Override
	public String getName() {
		return name;
	}

	// Returns the defense value of the Shield
	public int getDefense() {
		return defense;
	}

	// Returns a string representation of the Shield
	@Override
	public String toString() {
		return getName();
	}

	// Returns the width of the Shield item (assuming the width is 2)
	@Override
	public int itemWidth() {
		return 2;
	}

	// Returns the height of the Shield item (assuming the height is 2)
	@Override
	public int itemHeight() {
		return 2;
	}
}
