package fr.uge.items;

import java.util.Objects;

public record MagicObject(String name, int power) implements Item {

	// Constructor for creating a MagicObject
	public MagicObject(String name, int power) {
		Objects.requireNonNull(name, "name ne peut être nul");

		this.name = name;
		this.power = power;
	}

	// Returns the name of the MagicObject
	@Override
	public String getName() {
		return name;
	}

	// Returns the power of the MagicObject
	public int getPower() {
		return power;
	}

	// Returns a string representation of the MagicObject
	@Override
	public String toString() {
		return getName();
	}

	// Returns the width of the MagicObject item (assuming the width is 1)
	@Override
	public int itemWidth() {
		return 1;
	}

	// Returns the height of the MagicObject item (assuming the height is 1)
	@Override
	public int itemHeight() {
		return 1;
	}
}
