package fr.uge.items;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Objects;
import java.util.function.Consumer;

public class DisplayButton {
	private final int x;
	private final int y;
	private final int width;
	private final int height;
	private final Color color;
	private String text;
	private Consumer<MouseEvent> onClick;

	public DisplayButton(int x, int y, int width, int height, Color color) {
		Objects.requireNonNull(color, "color ne peut être nul");

		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
		this.text = "";
		this.onClick = null;
	}

	public void display(Graphics2D graphics) {
		Objects.requireNonNull(graphics, "graphics ne peut être nul");

		graphics.setColor(color);
		graphics.fillRect(x, y, width, height);
		graphics.setColor(Color.BLACK);
		graphics.drawRect(x, y, width, height);

		graphics.setFont(new Font("Arial", Font.PLAIN, 12));
		int textWidth = graphics.getFontMetrics().stringWidth(text);
		int textHeight = graphics.getFontMetrics().getHeight();
		graphics.drawString(text, x + width / 2 - textWidth / 2, y + height / 2 + textHeight / 2);
	}

	public boolean isClicked(int mouseX, int mouseY) {
		return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
	}

	public void setText(String text) {
		Objects.requireNonNull(text, "text ne peut être nul");
		this.text = text;
	}

	public void setOnClick(Consumer<MouseEvent> onClick) {
		this.onClick = onClick;
	}

}
