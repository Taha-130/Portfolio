package fr.uge.items;

import java.util.Objects;

public record ManaStone(String name, int mana) implements Item {

	// Constructor for creating a ManaStone
	public ManaStone(String name, int mana) {
		Objects.requireNonNull(name, "name ne peut être nul");

		this.name = name;
		this.mana = mana;
	}

	// Returns the name of the ManaStone
	@Override
	public String getName() {
		return name;
	}

	// Returns the mana value of the ManaStone
	public int getMana() {
		return mana;
	}

	// Returns a string representation of the ManaStone
	@Override
	public String toString() {
		return getName();
	}

	// Returns the width of the ManaStone item (assuming the width is 1)
	@Override
	public int itemWidth() {
		return 1;
	}

	// Returns the height of the ManaStone item (assuming the height is 1)
	@Override
	public int itemHeight() {
		return 1;
	}
}
