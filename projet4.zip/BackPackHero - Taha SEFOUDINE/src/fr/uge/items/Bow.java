package fr.uge.items;

import java.util.Objects;

public record Bow(String name, int damage, int range) implements Item {

	// Constructor for creating a Bow object
	public Bow(String name, int damage, int range) {
		Objects.requireNonNull(name, "name ne peut être nul");

		this.name = name;
		this.damage = damage;
		this.range = range;
	}

	// Returns the name of the bow
	@Override
	public String getName() {
		return name;
	}

	// Returns the damage value of the bow
	public int getDamage() {
		return damage;
	}

	// Returns the range value of the bow
	public int getRange() {
		return range;
	}

	// Returns a string representation of the bow
	@Override
	public String toString() {
		return getName();
	}

	// Returns the width of the bow item (assuming the width is 1)
	@Override
	public int itemWidth() {
		// TODO Auto-generated method stub
		return 1;
	}

	// Returns the height of the bow item (assuming the height is 2)
	@Override
	public int itemHeight() {
		// TODO Auto-generated method stub
		return 2;
	}
}
