package fr.uge.items;

import java.util.Objects;

public record Sword(String name, int damage) implements Item {

	// Constructor for creating a Sword
	public Sword(String name, int damage) {
		Objects.requireNonNull(name, "name ne peut être nul");
		this.name = name;
		this.damage = damage;
	}

	// Returns the name of the Sword
	@Override
	public String getName() {
		return name;
	}

	// Returns the damage value of the Sword
	public int getDamage() {
		return damage;
	}

	// Returns a string representation of the Sword
	@Override
	public String toString() {
		return getName();
	}

	// Returns the width of the Sword item (assuming the width is 1)
	@Override
	public int itemWidth() {
		return 1;
	}

	// Returns the height of the Sword item (assuming the height is 3)
	@Override
	public int itemHeight() {
		return 3;
	}
}
