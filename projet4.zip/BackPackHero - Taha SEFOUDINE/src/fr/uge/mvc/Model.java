package fr.uge.mvc;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import javax.imageio.ImageIO;

import fr.uge.persona.Hero;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.Event.Action;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

import fr.uge.items.Armor;
import fr.uge.items.Bow;
import fr.uge.items.DisplayButton;
import fr.uge.items.Gold;
import fr.uge.items.Item;
import fr.uge.items.MagicObject;
import fr.uge.items.ManaStone;
import fr.uge.items.Shield;
import fr.uge.items.Sword;
import java.util.Random;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Model {
	private static ApplicationContext context; // Assuming context is a member variable in GameData

	// Constructor to initialize the context
	public Model(ApplicationContext context) {
		this.context = context;
	}

	private static final String DATA_FOLDER = "data/";
	public static final BufferedImage[] donjonImages = { loadImage("donjon2.png"), loadImage("donjon3.png"),
			loadImage("donjon4.png"), loadImage("donjon5.png"), loadImage("donjon6.png") };

	// Declare image arrays for other dungeons if needed

	private static BufferedImage loadImage(String imageName) {
		Objects.requireNonNull(imageName, "imageName ne peut être nul");

		String imagePath = DATA_FOLDER + imageName;
		try {
			File file = new File(imagePath);
			return ImageIO.read(file);
		} catch (IOException e) {
			e.printStackTrace();
			return null; // Return null in case of failure to load the image
		}
	}

	// Retourne le nom de l'image correspondant à l'indice du donjon
	public static String getDonjonImageName(int donjonIndex) {
		return "donjon" + (donjonIndex + 2) + ".png";
	}

	// Génère une couleur aléatoire
	public static Color generateRandomColor() {
		Random random = new Random();
		int r = random.nextInt(256);
		int g = random.nextInt(256);
		int b = random.nextInt(256);
		return new Color(r, g, b);
	}

	// Gère l'entrée dans un donjon
	public static void handleDonjonEntrance(ApplicationContext context, int donjonId, Event event) {
		Objects.requireNonNull(context, "context ne peut être nul");

		String donjonImage = "donjon" + donjonId + ".png";
		Color donjonColor = generateRandomColor();
		Vue.clearGame(context);

		Vue.donjon(donjonId, donjonColor, donjonImage, context, event);
	}

	// Génère un identifiant de donjon unique
	public static int generateUniqueDonjonId(Random random, List<Integer> visitedDungeons) {
		Objects.requireNonNull(random, "random ne peut être nul");
		Objects.requireNonNull(visitedDungeons, "visitedDungeons ne peut être nul");

		int donjonId;
		do {
			donjonId = random.nextInt(6) + 1;
		} while (visitedDungeons.contains(donjonId));
		visitedDungeons.add(donjonId);
		return donjonId;
	}

	public static void saveScore(String playerName, int score) {
	    try (PrintWriter writer = new PrintWriter(new FileWriter("Hall_of_Fame.txt", true))) {
	        writer.println(playerName + ": " + score);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	public static int loadPlayerCounter() {
	    int playerCounter = 0;
	    try (BufferedReader reader = new BufferedReader(new FileReader("Hall_of_Fame.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            if (line.startsWith("Joueur ")) {
	                playerCounter++;
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return playerCounter;
	}


}
