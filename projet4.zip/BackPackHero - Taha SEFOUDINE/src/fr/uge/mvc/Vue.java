package fr.uge.mvc;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.imageio.ImageIO;

import fr.uge.items.DisplayButton;
import fr.uge.items.Item;
import fr.uge.persona.Enemy;
import fr.uge.persona.Hero;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.Event.Action;
import java.awt.Graphics;
import java.util.Random;

public class Vue {

	// le statut des donjons non visités
	private static boolean donjon2Visited = false;
	private static boolean donjon3Visited = false;
	private static boolean donjon4Visited = false;
	private static boolean donjon5Visited = false;
	private static boolean donjon6Visited = false;

	// Méthode privée pour dessiner une image
	private static void drawImage(Graphics2D graphics, BufferedImage image, float x, float y, float dimX, float dimY) {
		Objects.requireNonNull(graphics, "graphics ne peut être nul");
		Objects.requireNonNull(image, "image ne peut être nul");

		var width = image.getWidth();
		var height = image.getHeight();
		var scale = Math.min(dimX / width, dimY / height);
		var transform = new AffineTransform(scale, 0, 0, scale, x + (dimX - scale * width) / 2,
				y + (dimY - scale * height) / 2);
		graphics.drawImage(image, transform, null);
	}

	public static void displayBackpack(ApplicationContext context, Hero hero, Event event) {
		Objects.requireNonNull(context, "context ne peut être nul");
		Objects.requireNonNull(hero, "hero ne peut être nul");

		// Définition des variables de position et de dimension des objets dans le sac à
		// dos
		var margin = 100;
		int rows = 3;
		int cols = 5;
		int squareSize = 50;

		int startX = 100;
		int startY = 100;
		int itemSpacing = 30;
		int itemWidth = 1; // Largeur de l'item dans le sac à dos
		int itemHeight = 3; // Hauteur de l'item dans le sac à dos

		// Récupération des objets dans le sac à dos du héros
		List<Item> backpackItems = hero.getBackpack();

		// Affichage de la grille du sac à dos et des objets dans une interface
		// graphique
		context.renderFrame(graphics -> {
			// Dessiner la grille du sac à dos
			drawBackpackGrid(graphics, margin, rows, cols, squareSize);

			// Dessiner les objets dans le sac à dos
			drawItemsInBackpack(context, graphics, startX, startY, itemSpacing, itemWidth, itemHeight, squareSize,
					event, backpackItems);
		});
	}

	// Dessiner la grille du sac à dos
	private static void drawBackpackGrid(Graphics graphics, int margin, int rows, int cols, int squareSize) {
		Objects.requireNonNull(graphics, "graphics ne peut être nul");

		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				graphics.setColor(Color.WHITE);
				graphics.fillRect(col * squareSize + margin, row * squareSize + margin, squareSize, squareSize);
				graphics.setColor(Color.BLACK);
				graphics.drawRect(col * squareSize + margin, row * squareSize + margin, squareSize, squareSize);
			}
		}
	}

	// Dessiner les objets dans le sac à dos
	// Dessiner les objets dans le sac à dos

	// ...

	private static void drawItemsInBackpack(ApplicationContext context, Graphics2D graphics, int startX, int startY,
			int itemSpacing, int itemWidth, int itemHeight, int squareSize, Event event, List<Item> backpackItems) {
		// Vérifier que les paramètres obligatoires ne sont pas nuls
		Objects.requireNonNull(context, "context ne peut être nul");
		Objects.requireNonNull(graphics, "graphics ne peut être nul");
		Objects.requireNonNull(backpackItems, "backpackItems ne peut être nul");

		int cols = 5; // Nombre de colonnes dans la grille du sac à dos

		for (int i = 0; i < backpackItems.size(); i++) {
			final int index = i;
			Item item = backpackItems.get(i);
			String itemName = item.getName();
			int itemWidth1 = item.itemWidth();
			int itemHeight1 = item.itemHeight();

			// Charger l'image
			String imageName = itemName.toLowerCase() + ".png";
			String imagePath = "data/" + imageName;
			try {
				Path imageFile = Paths.get(imagePath);
				BufferedImage image = ImageIO.read(imageFile.toFile());

				// Calculer la position de l'objet dans le sac à dos
				int itemX = startX + (index % cols) * squareSize;
				int itemY = startY + (index / cols) * squareSize;

				// Dessiner le nom de l'objet dans le sac à dos
				graphics.setColor(Color.YELLOW);
				graphics.drawString(itemName, itemX, itemY + itemSpacing);

				// Ajuster la position de l'image à côté du héros
				int imageX = itemX + (itemWidth1 * squareSize) + 10; // 10 est l'espacement entre l'objet et l'image
				int imageY = itemY;
				graphics.drawImage(image, imageX, imageY, itemWidth1 * squareSize, itemHeight1 * squareSize, null);

				// Vérifier si le clic de souris est à l'intérieur des limites de l'objet
				if (isMouseWithinItem(context, itemX, itemY, itemWidth1, itemHeight1, event)) {
					if (event.getAction() == Action.POINTER_DOWN) { // Vérifier si un bouton de la souris a été enfoncé
						// Réaliser l'action souhaitée lorsque l'objet est cliqué
						int mouseX = (int) event.getLocation().getX();
						int mouseY = (int) event.getLocation().getY();
						int clickedIndex = (mouseY - startY) / squareSize * cols + (mouseX - startX) / squareSize;

						if (clickedIndex >= 0 && clickedIndex < backpackItems.size()) {
							// Réaliser l'action avec l'objet cliqué
							// Par exemple, mettre à jour sa position dans le sac à dos ou utiliser l'objet
							// Ici, nous pouvons échanger les positions de l'objet cliqué et du
							Collections.swap(backpackItems, index, clickedIndex);
						}
					}
				}

			} catch (IOException e) {
				// Gérer l'exception
			}
		}
	}

	public static void displayBackground(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		// Obtenir les informations sur l'écran
		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();

		// Rendre l'image d'arrière-plan dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "background.png"))), 0, 0,
						width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void displayCarte(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var width = 50;
		var height = 50;
		var carteX = 1230;
		var carteY = 70;

		// Rendre l'image de la carte dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "carte.png"))), carteX,
						carteY, width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void displayEntireCarte(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var width = 500;
		var height = 500;

		// Rendre l'image de la carte entière dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "entire_carte.png"))), 500,
						0, width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void hideCarte(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		BufferedImage carteImage;
		try {
			carteImage = ImageIO.read(Files.newInputStream(Path.of("data/carte.png")));
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
		var carteX = 1230;
		var carteY = 70;
		var carteWidth = 50;
		var carteHeight = 50;

		// Rendre l'image de la carte masquée dans le contexte graphique
		context.renderFrame(graphics -> {
			drawImage(graphics, carteImage, carteX, carteY, carteWidth, carteHeight);
		});
	}

	public static void hero(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var width = 80;
		var height = 80;

		// Rendre l'image du héros dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "hero.png"))), 362, 620,
						width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void merchant(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var width = 80;
		var height = 80;

		// Rendre l'image du marchand dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "merchant.png"))), 524,
						620, width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void displayHealingBackground(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();

		// Rendre l'image de l'arrière-plan de guérison dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics,
						ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "healing_background.png"))), 0, 0,
						width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void displayMerchantBackground(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();

		// Rendre l'image de l'arrière-plan du marché dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "market.png"))), 0, 0,
						width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void displayChestBackground(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();

		// Rendre l'image de l'arrière-plan du coffre dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "chest2.png"))), 0, 0,
						width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void displayExit(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();

		// Rendre l'image de la sortie dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "exit.png"))), 0, 0, width,
						height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void healer(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var width = 80;
		var height = 80;

		// Rendre l'image du guérisseur dans le contexte graphique
		context.renderFrame(graphics -> {
			try {
				drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + "healer.png"))), 524, 620,
						width, height);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public static void randomEnemy(ApplicationContext context, Enemy enemy) {
		// Vérifier que les paramètres obligatoires ne sont pas nuls
		Objects.requireNonNull(context, "context ne peut être nul");
		Objects.requireNonNull(enemy, "enemy ne peut être nul");

		var width = 80;
		var height = 80;

		Random random = new Random();
		String[] enemyImages = { "reine.png", "small_rat_loup.png", "sorcier.png", "rat_loup.png",
				"living_shadow.png" };
		int randomIndex = random.nextInt(enemyImages.length);
		String enemyImage = enemyImages[randomIndex];

		// Rendre l'image de l'ennemi aléatoire dans le contexte graphique
		context.renderFrame(graphics -> {
			if (enemy.isAlive()) {
				try {
					drawImage(graphics, ImageIO.read(Files.newInputStream(Path.of("data" + "/" + enemyImage))), 524,
							620, width, height);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void hideEnemy(ApplicationContext context) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(context, "context ne peut être nul");

		var width = 80;
		var height = 80;
		BufferedImage transparentImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		var enemyX = 524;
		var enemyY = 620;

		// Rendre l'ennemi invisible en dessinant une image transparente sur son
		// emplacement
		context.renderFrame(graphics -> {
			graphics.clearRect(enemyX, enemyY, width, height);
			drawImage(graphics, transparentImage, enemyX, enemyY, width, height);
		});
	}

	private static void resetHeroHealthPoints(Hero hero) {
		// Vérifier que le paramètre obligatoire n'est pas nul
		Objects.requireNonNull(hero, "hero ne peut être nul");

		int previousHealthPoints = hero.getHealthPoints();
		Hero.resetHealthPoints(); // Réinitialiser les points de vie du héros
	}

	public static void donjon(int donjonNumber, Color buttonColor, String imageFileName, ApplicationContext context,
			Event event) {
		// Vérifier que les paramètres obligatoires ne sont pas nuls
		Objects.requireNonNull(buttonColor, "buttonColor ne peut être nul");
		Objects.requireNonNull(imageFileName, "imageFileName ne peut être nul");
		Objects.requireNonNull(context, "context ne peut être nul");

		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();
		DisplayButton attackButton = new DisplayButton(100, 100, 80, 40, buttonColor);
		attackButton.setText("Attack");

		DisplayButton defenseButton = new DisplayButton(200, 100, 80, 40, buttonColor);
		defenseButton.setText("Defense");

		boolean donjonVisited = checkDonjonVisited(donjonNumber);
		if (donjonVisited) {
			displayDonjonVisitedMessage(donjonNumber);
			return;
		}

		context.renderFrame(graphics -> {
			try {
				drawDonjonImage(graphics, imageFileName, (int) width, (int) height);
				displayAttackAndDefenseButtons(graphics, attackButton, defenseButton);

				Hero hero = new Hero();
				Enemy enemy = new Enemy();

				initializeHero(context);
				resetHeroHealthPoints(hero);

				initializeEnemy(context, enemy);

				System.out.println("Dans le donjon " + donjonNumber);
				performCombat(hero, enemy, attackButton, defenseButton, context);

				System.out.println(enemy.getHealthPoints());
				System.out.println(hero.getHealthPoints());

				if (!enemy.isAlive()) {
					handleEnemyDefeated(context, hero, event);
				} else {
					displayGameOver(context);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

		updateDonjonVisitedStatus(donjonNumber);
	}

	private static boolean checkDonjonVisited(int donjonNumber) {
		boolean donjonVisited = false;
		switch (donjonNumber) {
		case 2:
			donjonVisited = donjon2Visited;
			break;
		case 3:
			donjonVisited = donjon3Visited;
			break;
		case 4:
			donjonVisited = donjon4Visited;
			break;
		case 5:
			donjonVisited = donjon5Visited;
			break;
		case 6:
			donjonVisited = donjon6Visited;
			break;
		default:
			// Numéro de donjon invalide, gérer l'erreur ou retourner
			return true;
		}
		return donjonVisited;
	}

	private static void displayDonjonVisitedMessage(int donjonNumber) { // Affiche un message indiquant que le donjon a
																		// déjà été visité
		System.out.println("Le donjon " + donjonNumber + " a déjà été visité !");
	}

	private static void drawDonjonImage(Graphics2D graphics, String imageFileName, int width, int height)
			throws IOException { // Dessine l'image du donjon sur le graphique
		BufferedImage image = ImageIO.read(Files.newInputStream(Path.of("data" + "/" + imageFileName)));
		graphics.drawImage(image, 0, 0, width, height, null);
	}

	private static void displayAttackAndDefenseButtons(Graphics2D graphics, DisplayButton attackButton,
			DisplayButton defenseButton) { // Affiche les boutons d'attaque et de défense
		Objects.requireNonNull(graphics, "graphics ne peut être nul");
		Objects.requireNonNull(attackButton, "attackButton ne peut être nul");
		Objects.requireNonNull(defenseButton, "defenseButton ne peut être nul");
		attackButton.display(graphics);
		defenseButton.display(graphics);
	}

	private static void initializeHero(ApplicationContext context) { // Initialise le héros
		Objects.requireNonNull(context, "context ne peut être nul");
		hero(context);
	}

	private static void initializeEnemy(ApplicationContext context, Enemy enemy) { // Initialise l'ennemi
		Objects.requireNonNull(context, "context ne peut être nul");
		Objects.requireNonNull(enemy, "enemy ne peut être nul");
		randomEnemy(context, enemy);
	}

	private static void performCombat(Hero hero, Enemy enemy, DisplayButton attackButton, DisplayButton defenseButton,
			ApplicationContext context) { // Effectue le combat entre le héros et l'ennemi
		Objects.requireNonNull(hero, "hero ne peut être nul");
		Objects.requireNonNull(enemy, "enemy ne peut être nul");
		Objects.requireNonNull(attackButton, "attackButton ne peut être nul");
		Objects.requireNonNull(defenseButton, "defenseButton ne peut être nul");
		Objects.requireNonNull(context, "context ne peut être nul");
		hero.fight(enemy, attackButton, defenseButton, context);
	}

	private static void handleEnemyDefeated(ApplicationContext context, Hero hero, Event event) { // Gère la défaite de
																									// l'ennemi
		Objects.requireNonNull(context, "context ne peut être nul");
		Objects.requireNonNull(hero, "hero ne peut être nul");
		hideEnemy(context);
		displayEntireCarte(context);
		Vue.displayBackpack(context, hero, event);
	}

	private static void updateDonjonVisitedStatus(int donjonNumber) { // Met à jour le statut de visite du donjon
		switch (donjonNumber) {
		case 2:
			donjon2Visited = true;
			break;
		case 3:
			donjon3Visited = true;
			break;
		case 4:
			donjon4Visited = true;
			break;
		case 5:
			donjon5Visited = true;
			break;
		case 6:
			donjon6Visited = true;
			break;
		default:
			// Numéro de donjon invalide, gérer l'erreur ou retourner
			return;
		}
	}

	public static void clearGame(ApplicationContext context) { // Efface le jeu en remplissant l'écran de noir
		Objects.requireNonNull(context, "context ne peut être nul");
		context.renderFrame(graphics -> {
			var screenInfo = context.getScreenInfo();
			var width = screenInfo.getWidth();
			var height = screenInfo.getHeight();
			graphics.setColor(Color.BLACK);
			graphics.fillRect(0, 0, (int) width, (int) height);
		});
	}

	public static void displayGameOver(ApplicationContext context) { // Affiche l'écran de fin de jeu avec le message
																		// "Game Over"
		Objects.requireNonNull(context, "context ne peut être nul");
		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();

		context.renderFrame(graphics -> {
			graphics.setColor(Color.BLACK);
			graphics.fillRect(0, 0, (int) width, (int) height);
			graphics.setColor(Color.RED);
			graphics.drawString("Game Over", width / 2 - 50, height / 2);
		});
	}

	public enum MouseButton {
		LEFT, RIGHT
	}

	public static boolean isMouseWithinItem(ApplicationContext context, int itemX, int itemY, int itemWidth,
			int itemHeight, Event event) { // Vérifie si la souris est dans un élément spécifié
		Objects.requireNonNull(context, "context ne peut être nul");
		Point2D.Float mousePosition = event.getLocation();
		int mouseX = (int) mousePosition.getX();
		int mouseY = (int) mousePosition.getY();

		int itemRight = itemX + (int) (itemWidth * context.getScreenInfo().getWidth() / 100);
		int itemBottom = itemY + (int) (itemHeight * context.getScreenInfo().getHeight() / 100);

		return mouseX >= itemX && mouseX <= itemRight && mouseY >= itemY && mouseY <= itemBottom;
	}

	public static void displayHeroHealthPoints(ApplicationContext context, int healthPoints) { // Affiche les points de
																								// vie du héros
		Objects.requireNonNull(context, "context ne peut être nul");

		context.renderFrame(graphics -> {
			graphics.setColor(Color.RED);
			graphics.setFont(new Font("Arial", Font.PLAIN, 12));
			graphics.drawString("Hero PV: " + healthPoints, 10, 30);
		});
	}

	public static DisplayButton createHealButton(ApplicationContext context, int x, int y, int width, int height,
			Color color) { // Crée un bouton de guérison avec les paramètres spécifiés
		DisplayButton healButton = new DisplayButton(x, y, width, height, color);
		healButton.setText("Heal");
		return healButton;
	}

}