package fr.uge.mvc;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.Event.Action;
import fr.umlv.zen5.KeyboardKey;
import fr.uge.items.Armor;
import fr.uge.items.Bow;
import fr.uge.items.DisplayButton;
import fr.uge.items.Gold;
import fr.uge.items.Item;
import fr.uge.items.MagicObject;
import fr.uge.items.ManaStone;
import fr.uge.items.Shield;
import fr.uge.items.Sword;
import fr.uge.persona.Hero;
import java.util.Scanner;

public class Controler {
	private static final int TOTAL_DONJONS = 5; // Nombre total de donjons
	private static int donjonsTermines = 0;
	private static List<Integer> visitedDungeons = new ArrayList<>();
	Scanner scanner = new Scanner(System.in); // Créer une instance de la classe Scanner
	private static int playerCounter;

	private static void memoryGame(ApplicationContext context) {
		Objects.requireNonNull(context, "context ne peut être nul");

		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();
		var carteX = 1230;
		var carteY = 70;
		var carteWidth = 50;
		var carteHeight = 50;
		var carteAffichee = false; // Ajout de la variable carteAffichee

		Hero hero = new Hero();
		Event event = null; // Déclaration de l'event

		boolean donjonTermine = false; // Nouvelle variable pour indiquer si le donjon est terminé

		context.renderFrame(graphics -> {
			Vue.displayBackground(context);
			Vue.displayCarte(context);
			Vue.displayBackpack(context, hero, event); // Pass the event as an argument
		});

		Random random = new Random();

		while (true) {
			var event1 = context.pollOrWaitEvent(10);
			if (event1 == null) {
				continue;
			}
			var action = event1.getAction();

			if (action == Action.KEY_PRESSED) {
				if (event1.getKey() == KeyboardKey.Q) {
					if (carteAffichee) {
						Vue.hideCarte(context); // Cacher la carte avant de quitter
						carteAffichee = false; // Remettre la variable carteAffichee à false
					} else {
						context.exit(0);
					}
				} else {
					System.out.println(event1.getKey());
				}

			} else if (action == Action.POINTER_DOWN) {
				var location = event1.getLocation();
				int mouseX = (int) location.getX();
				int mouseY = (int) location.getY(); // affiche les coordonnées du clic
				System.out.println(location);
				if (carteAffichee) {
					// Si la carte est actuellement affichée et que l'utilisateur clique dessus,
					// on la cache et on met la variable carteAffichee à false
					if (location.getX() >= carteX && location.getX() <= carteX + carteWidth && location.getY() >= carteY
							&& location.getY() <= carteY + carteHeight) {
						Vue.hideCarte(context);
						carteAffichee = false;
					}
					// Si la carte est affichée et que l'utilisateur clique sur l'entrée du donjon,
					// on affiche une image de donjon aléatoire

					if (Math.abs(location.getX() - 523) < 5 && Math.abs(location.getY() - 167) < 5
							|| Math.abs(location.getX() - 931) < 5 && Math.abs(location.getY() - 213) < 5) {
						int donjonId = Model.generateUniqueDonjonId(random, visitedDungeons);
						Model.handleDonjonEntrance(context, donjonId, event1);
						donjonsTermines++; //
						donjonTermine = true; // Indiquer que le donjon est terminé
					} else if (Math.abs(location.getX() - 613) < 5 && Math.abs(location.getY() - 259) < 5) {
						int donjonId = Model.generateUniqueDonjonId(random, visitedDungeons);
						Model.handleDonjonEntrance(context, donjonId, event1);
						donjonsTermines++; // Incrémenter le compteur des donjons terminés
						donjonTermine = true; // Indiquer que le donjon est terminé
					} else if (Math.abs(location.getX() - 571) < 5 && Math.abs(location.getY() - 350) < 5) {
						int donjonId = Model.generateUniqueDonjonId(random, visitedDungeons);
						Model.handleDonjonEntrance(context, donjonId, event1);
						donjonsTermines++; // Incrémenter le compteur des donjons terminés
						donjonTermine = true; // Indiquer que le donjon est terminé
					} else if (Math.abs(location.getX() - 704) < 5 && Math.abs(location.getY() - 214) < 5) {
						int donjonId = Model.generateUniqueDonjonId(random, visitedDungeons);
						Model.handleDonjonEntrance(context, donjonId, event1);
						donjonsTermines++; // Incrémenter le compteur des donjons terminés
						donjonTermine = true; // Indiquer que le donjon est terminé
					} else if (Math.abs(location.getX() - 931) < 5 && Math.abs(location.getY() - 259) < 5) {
						int donjonId = Model.generateUniqueDonjonId(random, visitedDungeons);
						Model.handleDonjonEntrance(context, donjonId, event1);
						donjonsTermines++; // Incrémenter le compteur des donjons terminés
						donjonTermine = true; // Indiquer que le donjon est terminé
						if (donjonTermine) {
						}
					} else if (Math.abs(location.getX() - 750) < 5 && Math.abs(location.getY() - 215) < 5) {
						System.out.println("Zone de la guérisseuse");
						Vue.clearGame(context);
						Vue.displayHealingBackground(context);
						Vue.healer(context);
						Vue.hero(context);

						int heroHealthPoints = hero.getHealthPoints();

						DisplayButton healButton = new DisplayButton(250, 173, 100, 40, Color.GREEN);
						healButton.setText("Heal");

						context.renderFrame(graphics -> {
							healButton.display(graphics);
							graphics.clearRect(10, 10, 200, 20);
							Vue.displayHeroHealthPoints(context, heroHealthPoints);
						});

						boolean healButtonClicked = false; // Variable pour vérifier si le bouton de guérison a été
															// cliqué

						while (!healButtonClicked) {
							var event11 = context.pollOrWaitEvent(10);
							if (event11 != null && event11.getAction() == Action.POINTER_DOWN) {
								int clickX = (int) event11.getLocation().getX();
								int clickY = (int) event11.getLocation().getY();

								System.out.println("Clicked at: " + clickX + ", " + clickY);
								if (healButton.isClicked(clickX, clickY)) {
									System.out.println("Clicked Heal button");

									int experienceCost = 10; // Example: Healing costs 10 experience points
									int healthPointsGained = 10; // Example: Healing restores 20 health points
									if (hero.getExperiencePoints() >= experienceCost && heroHealthPoints < 40) {
										hero.decreaseExperiencePoints(experienceCost);
										hero.increaseHealthPoints(healthPointsGained);
										int newHeroHealthPoints = hero.getHealthPoints();
										if (newHeroHealthPoints > 40) {
											newHeroHealthPoints = 40;
										}
										System.out.println(newHeroHealthPoints);
										context.renderFrame(graphics -> {
											graphics.clearRect(10, 10, 200, 20);
										});
										Vue.displayHeroHealthPoints(context, newHeroHealthPoints);
										Hero.endCombat();
										healButtonClicked = true;

									} else {
										System.out.println(
												"Le héros n'a pas assez d'expérience pour effectuer la guérison.");

										healButtonClicked = true;

										// Affichez un message ou effectuez une action appropriée lorsque le héros n'a
										// pas assez d'expérience
									}
									// Le bouton de guérison a été cliqué, sortir de la boucle
									// Ajoutez ici votre logique de guérison
								}
							}
						}
					}

					else if (Math.abs(location.getX() - 570) < 5 && Math.abs(location.getY() - 168) < 5
							|| Math.abs(location.getX() - 978) < 5 && Math.abs(location.getY() - 213) < 5) {
						// Zone du marchand
						System.out.println("Zone du marchand");

						boolean MerchantZone = true;

						Vue.clearGame(context);
						Vue.displayMerchantBackground(context);
						Vue.merchant(context);
						Vue.hero(context);

						DisplayButton buyButton = new DisplayButton(300, 200, 100, 40, Color.GREEN);
						buyButton.setText("Buy");

						DisplayButton sellButton = new DisplayButton(300, 300, 100, 40, Color.RED);
						sellButton.setText("Sell");

						while (MerchantZone) {
							var event11 = context.pollOrWaitEvent(10);
							if (event11 != null && event11.getAction() == Action.POINTER_DOWN) {
								int clickX = (int) event11.getLocation().getX();
								int clickY = (int) event11.getLocation().getY();

								System.out.println("Clicked at: " + clickX + ", " + clickY);

								if (buyButton.isClicked(clickX, clickY)) {
									System.out.println("Clicked Buy button");
									MerchantZone = false;

									// Affichage du contenu du backpack
									List<Item> backpackItems = hero.getBackpack();
									int startY = 100;
									context.renderFrame(graphics -> {
										// Affichage du contenu du backpack
										graphics.setColor(Color.WHITE);
										graphics.drawString("Backpack contents:", 20, startY);
										for (int i = 0; i < backpackItems.size(); i++) {
											graphics.drawString("- " + backpackItems.get(i).getName(), 20,
													startY + (i + 1) * 20);
										}
									});

								} else if (sellButton.isClicked(clickX, clickY)) {
									System.out.println("Clicked Sell button");
									MerchantZone = false;

									// Affichage du contenu du backpack
									List<Item> backpackItems = hero.getBackpack();
									int startY = 100;
									context.renderFrame(graphics -> {
										// Affichage du contenu du backpack
										graphics.setColor(Color.WHITE);
										graphics.drawString("Backpack contents:", 20, startY);
										for (int i = 0; i < backpackItems.size(); i++) {
											graphics.drawString("- " + backpackItems.get(i).getName(), 20,
													startY + (i + 1) * 20);
										}
									});
								}

							}

							// Affichage des boutons
							context.renderFrame(graphics -> {
								buyButton.display(graphics);
								sellButton.display(graphics);
							});
						}
					} else if (Math.abs(location.getX() - 617) < 5 && Math.abs(location.getY() - 304) < 5
							|| Math.abs(location.getX() - 931) < 5 && Math.abs(location.getY() - 350) < 5) {
						Vue.clearGame(context);
						Vue.displayChestBackground(context);
						Vue.hero(context);
						Vue.displayBackpack(context, hero, event1);

						DisplayButton openButton = new DisplayButton(400, 200, 100, 40, Color.YELLOW);
						openButton.setText("Open");
						context.renderFrame(graphics -> {
							openButton.display(graphics);
						});

						boolean openButtonClicked = false;

						while (!openButtonClicked) {
							var event11 = context.pollOrWaitEvent(10);
							if (event11 != null && event11.getAction() == Action.POINTER_DOWN) {
								int clickX = (int) event11.getLocation().getX();
								int clickY = (int) event11.getLocation().getY();

								System.out.println("Clicked at: " + clickX + ", " + clickY);
								if (openButton.isClicked(clickX, clickY)) {
									System.out.println("Clicked Open button");

									openButtonClicked = true;

									Random random1 = new Random();
									String[] items = { "sword", "bow", "gold", "manastone", "shield", "armor",
											"magiobject" };
									int index = random1.nextInt(items.length);
									String itemName = items[index];

									switch (itemName) {
									case "sword":
										Item sword = new Sword("Sword", 20);
										hero.takeItem(sword);
										break;
									case "bow":
										Item bow = new Bow("Bow", 15, 10);
										hero.takeItem(bow);
										break;
									case "gold":
										Item gold = new Gold("Gold", 100);
										hero.takeItem(gold);
										break;
									case "manastone":
										Item manastone = new ManaStone("ManaStone", 5);
										hero.takeItem(manastone);
										break;
									case "shield":
										Item shield = new Shield("Shield", 10);
										hero.takeItem(shield);
										break;
									case "armor":
										Item armor = new Armor("Armor", 30);
										hero.takeItem(armor);
										break;
									case "magiobject":
										Item magiObject = new MagicObject("Magic_object", 25);
										hero.takeItem(magiObject);
										break;

									}
									Vue.displayBackpack(context, hero, event1);

								}
							}
						}
					} else if (Math.abs(location.getX() - 975) < 5 && Math.abs(location.getY() - 306) < 5
							|| Math.abs(location.getX() - 523) < 5 && Math.abs(location.getY() - 261) < 5) {
						Vue.clearGame(context);
						Vue.displayExit(context);
						String funnyMessage = "Déjà ! Vous êtes allé si vite.\nMais... c'est en cours de construction !\nVeuillez revenir plus tard.";

						context.renderFrame(graphics -> {
							graphics.setColor(Color.YELLOW);
							graphics.setFont(new Font("Arial", Font.BOLD, 25));

							// Calculate the X and Y coordinates for the centered message
							FontMetrics fontMetrics = graphics.getFontMetrics();
							int messageWidth = fontMetrics.stringWidth(funnyMessage);
							int messageHeight = fontMetrics.getHeight();
							int messageX = (int) ((width - messageWidth) / 2);
							int messageY = (int) ((height - messageHeight) / 2);
							graphics.drawString(funnyMessage, messageX, messageY);

						});
					}

					if (donjonsTermines == TOTAL_DONJONS) {
						// Charger le compteur de joueur à partir du fichier
						int playerCounter = Model.loadPlayerCounter();

						// Afficher l'écran noir si tous les donjons sont terminés
						String playerName = "Joueur " + playerCounter;

						// Enregistrer les points de vie
						int pointsDeVie = hero.getHealthPoints();

						// Enregistrer le score uniquement pour le dernier joueur
						Model.saveScore(playerName, pointsDeVie);

						context.renderFrame(graphics -> {
							graphics.setColor(Color.BLACK);
							graphics.fillRect(0, 0, (int) width, (int) height);
							graphics.setColor(Color.WHITE);
							graphics.drawString("Félicitations ! Vous avez terminé le jeu.", 100, 100);
						});

					}

				} else {
					// Si la carte n'est pas affichée et que l'utilisateur clique dessus,
					// on l'affiche et on met la variable carteAffichee à true
					if (location.getX() >= carteX && location.getX() <= carteX + carteWidth && location.getY() >= carteY
							&& location.getY() <= carteY + carteHeight) {
						Vue.displayEntireCarte(context);
						carteAffichee = true;
					}

				}
			}

			if (!carteAffichee && !donjonTermine) { // Si la carte n'est pas affichée et le donjon n'est pas terminé, on
													// affiche le jeu
				context.renderFrame(graphics -> {
					Vue.displayBackground(context);

					Vue.displayBackpack(context, hero, event1);
					Vue.displayCarte(context);
				});
			}
		}
	}

	public static void main(String[] args) {
		Application.run(Color.WHITE, Controler::memoryGame);
	}
}
